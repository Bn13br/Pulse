// Plugin do Android compatível com o Gradle 7.4.2 do AndroidIDE.
plugins {
    id("com.android.application") version "7.3.1" apply false
}
