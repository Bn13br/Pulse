package com.pulse.pulse;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import java.util.Locale;

/** Idioma escolhido dentro do app (independe do idioma do sistema). */
final class Lang {
    static final String PT = "pt";
    static final String EN = "en";

    private Lang() {}

    static String current(Context c) {
        SharedPreferences sp = c.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE);
        String code = sp.getString(Prefs.LANG, null);
        if (PT.equals(code) || EN.equals(code)) return code;
        return PT.equals(Locale.getDefault().getLanguage()) ? PT : EN;
    }

    static void set(Context c, String code) {
        c.getSharedPreferences(Prefs.NAME, Context.MODE_PRIVATE)
                .edit().putString(Prefs.LANG, code).apply();
    }

    /** Envolve o Context com o idioma escolhido (usado em attachBaseContext). */
    static Context wrap(Context base) {
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(new Locale(current(base)));
        return base.createConfigurationContext(cfg);
    }
}
